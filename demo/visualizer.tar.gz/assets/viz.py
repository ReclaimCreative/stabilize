import math
import collections
import pygame
import config
from triangulation import triangulate

# ── Palette ───────────────────────────────────────────────────────────────────
BG           = (15,  15,  25)
SURFACE_FILL = (30,  35,  50)
SURFACE_EDGE = (60,  70,  90)
GRID_CLR     = (40,  48,  65)
SENSOR_CLR   = (80,  180, 255)
TRUE_CLR     = (100, 220, 100)
TRIG_CLR     = (255,  90,  70)
LINE_A_CLR   = (80,  180, 255)
LINE_B_CLR   = (255, 160,  40)
ARC_A_CLR    = (40,  90,  130)
ARC_B_CLR    = (130, 80,   20)
HUD_CLR      = (190, 190, 190)
DIM_CLR      = (55,  55,  80)
LABEL_CLR    = (120, 130, 160)

GRID_CELLS = 5      # grid lines across each axis of surface


class Visualizer:

    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((config.SCREEN_W, config.SCREEN_H))
        pygame.display.set_caption("S-Table Sensor Visualizer")
        self.clock  = pygame.time.Clock()
        self.font_s = pygame.font.SysFont('monospace', 13)
        self.font_m = pygame.font.SysFont('monospace', 15)
        self.font_l = pygame.font.SysFont('monospace', 18, bold=True)
        self.trail         = collections.deque(maxlen=config.TRAIL_LEN)
        self.canvas        = pygame.Surface((config.SCREEN_W, config.SCREEN_H), pygame.SRCALPHA)
        self.last_draw_pos = None
        self.last_plot_pos = None   # for auto-plot continuity
        self.auto_plot     = False  # P key: continuously draw true_pos to canvas
        self._build_transform()

    # ── Coordinate transform ──────────────────────────────────────────────────

    def _build_transform(self):
        PAD     = 100
        world_w = config.SURFACE_X1 - config.SURFACE_X0 + 80
        world_h = config.SURFACE_D_MM + 80
        sx = (config.SCREEN_W - 2 * PAD) / world_w
        sy = (config.SCREEN_H - 2 * PAD) / world_h
        self.scale = min(sx, sy)
        # Sensor A slightly left of screen center, sensors near top
        self.ox = PAD + MARGIN_PX(self.scale)
        self.oy = PAD + 30

    def w2s(self, wx, wy):
        """World mm → screen px.  World +Y maps to screen down."""
        return (int(self.ox + wx * self.scale),
                int(self.oy + wy * self.scale))

    def s2w(self, sx, sy):
        """Screen px → world mm."""
        return ((sx - self.ox) / self.scale,
                (sy - self.oy) / self.scale)

    def mouse_world_pos(self):
        """Current mouse position in world mm."""
        return self.s2w(*pygame.mouse.get_pos())

    # ── Public interface ──────────────────────────────────────────────────────

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                if event.key == pygame.K_c:
                    self.canvas.fill((0, 0, 0, 0))
                if event.key == pygame.K_f:
                    config.FILTER_MODE = not config.FILTER_MODE
                if event.key == pygame.K_TAB:
                    config.MOUSE_MODE = not config.MOUSE_MODE
                    self._tab_pressed = True   # signal main loop to reset source
                if event.key == pygame.K_t:
                    config.TREMOR_MODE = not config.TREMOR_MODE
                if event.key == pygame.K_p:
                    self.auto_plot = not self.auto_plot
                    self.last_plot_pos = None
            if event.type == pygame.MOUSEBUTTONUP:
                self.last_draw_pos = None
        return True

    def render(self, d_a, d_b, true_pos=None, raw_pos=None, filtered_pos=None):
        self.screen.fill(BG)
        self._draw_surface()
        self._update_drawing()
        self._update_auto_plot(true_pos)
        self.screen.blit(self.canvas, (0, 0))
        self._draw_baseline()
        self._draw_sensors()
        self._draw_measurement(d_a, d_b, true_pos, raw_pos, filtered_pos)
        self._draw_hud(d_a, d_b, raw_pos, filtered_pos)
        self._draw_legend()
        pygame.display.flip()
        self.clock.tick(config.FPS)

    # ── Drawing ───────────────────────────────────────────────────────────────

    def _update_drawing(self):
        if not pygame.mouse.get_pressed()[0]:
            self.last_draw_pos = None
            return
        cur = pygame.mouse.get_pos()
        if self.last_draw_pos:
            pygame.draw.line(self.canvas, (255, 220, 80, 200),
                             self.last_draw_pos, cur, 3)
        else:
            pygame.draw.circle(self.canvas, (255, 220, 80, 200), cur, 2)
        self.last_draw_pos = cur

    def _update_auto_plot(self, true_pos):
        if not self.auto_plot or true_pos is None:
            self.last_plot_pos = None
            return
        cur = self.w2s(*true_pos)
        if self.last_plot_pos:
            pygame.draw.line(self.canvas, (80, 220, 255, 180),
                             self.last_plot_pos, cur, 2)
        else:
            pygame.draw.circle(self.canvas, (80, 220, 255, 180), cur, 1)
        self.last_plot_pos = cur

    # ── Static scene ──────────────────────────────────────────────────────────

    def _draw_surface(self):
        p0 = self.w2s(config.SURFACE_X0, config.SURFACE_Y0)
        p1 = self.w2s(config.SURFACE_X1, config.SURFACE_Y1)
        rect = pygame.Rect(p0[0], p0[1], p1[0] - p0[0], p1[1] - p0[1])
        pygame.draw.rect(self.screen, SURFACE_FILL, rect)

        # Grid
        step_x = config.SURFACE_W_MM / GRID_CELLS
        step_y = config.SURFACE_D_MM / GRID_CELLS
        for i in range(1, GRID_CELLS):
            x0 = self.w2s(config.SURFACE_X0 + i * step_x, config.SURFACE_Y0)
            x1 = self.w2s(config.SURFACE_X0 + i * step_x, config.SURFACE_Y1)
            pygame.draw.line(self.screen, GRID_CLR, x0, x1, 1)
            y0 = self.w2s(config.SURFACE_X0, config.SURFACE_Y0 + i * step_y)
            y1 = self.w2s(config.SURFACE_X1, config.SURFACE_Y0 + i * step_y)
            pygame.draw.line(self.screen, GRID_CLR, y0, y1, 1)

        pygame.draw.rect(self.screen, SURFACE_EDGE, rect, 2)

        lbl = self.font_s.render('500 mm × 500 mm detection surface', True, LABEL_CLR)
        self.screen.blit(lbl, (p0[0] + 6, p0[1] + 6))

    def _draw_baseline(self):
        sa = self.w2s(*config.SENSOR_A)
        sb = self.w2s(*config.SENSOR_B)
        pygame.draw.line(self.screen, DIM_CLR, sa, sb, 1)
        mid = self.w2s(config.BASELINE_MM / 2, 0)
        lbl = self.font_s.render(f'baseline  {config.BASELINE_MM:.1f} mm  (18")', True, DIM_CLR)
        self.screen.blit(lbl, (mid[0] - lbl.get_width() // 2, mid[1] - 20))

    def _draw_sensors(self):
        for label, pos, color in [
            ('A  (I2C1)', config.SENSOR_A, LINE_A_CLR),
            ('B  (I2C2)', config.SENSOR_B, LINE_B_CLR),
        ]:
            sp = self.w2s(*pos)
            pygame.draw.circle(self.screen, color, sp, 10)
            pygame.draw.circle(self.screen, (255, 255, 255), sp, 10, 1)
            txt = self.font_s.render(label, True, color)
            self.screen.blit(txt, (sp[0] - txt.get_width() // 2, sp[1] - 26))

    # ── Live data ─────────────────────────────────────────────────────────────

    def _draw_measurement(self, d_a, d_b, true_pos, raw_pos, filtered_pos):
        self._draw_range_arc(config.SENSOR_A, d_a, ARC_A_CLR)
        self._draw_range_arc(config.SENSOR_B, d_b, ARC_B_CLR)

        # Choose which point the trail and range lines follow
        display_pos = filtered_pos if (filtered_pos and config.FILTER_MODE) else raw_pos

        if display_pos:
            self.trail.append(display_pos)
            self._draw_trail()
            dp = self.w2s(*display_pos)
            pygame.draw.line(self.screen, LINE_A_CLR, self.w2s(*config.SENSOR_A), dp, 1)
            pygame.draw.line(self.screen, LINE_B_CLR, self.w2s(*config.SENSOR_B), dp, 1)

        # Raw triangulated point (dim, shows noise)
        if raw_pos and config.FILTER_MODE:
            rp = self.w2s(*raw_pos)
            pygame.draw.circle(self.screen, (140, 50, 40), rp, 5)

        # Filtered point (bright)
        if filtered_pos and config.FILTER_MODE:
            fp = self.w2s(*filtered_pos)
            pygame.draw.circle(self.screen, TRIG_CLR, fp, 9)
            pygame.draw.circle(self.screen, (255, 255, 255), fp, 9, 2)
        elif raw_pos:
            rp = self.w2s(*raw_pos)
            pygame.draw.circle(self.screen, TRIG_CLR, rp, 9)
            pygame.draw.circle(self.screen, (255, 255, 255), rp, 9, 2)

        if true_pos:
            tp = self.w2s(*true_pos)
            pygame.draw.circle(self.screen, TRUE_CLR, tp, 5)
            pygame.draw.circle(self.screen, (255, 255, 255), tp, 5, 1)

    def _draw_range_arc(self, sensor_pos, distance, color):
        """Thin arc at the measured distance, sweeping into the surface."""
        center = self.w2s(*sensor_pos)
        radius = int(abs(distance) * self.scale)
        if radius < 3 or radius > 3000:
            return
        rect = pygame.Rect(center[0] - radius, center[1] - radius,
                           radius * 2, radius * 2)
        try:
            # math.pi → 2*math.pi draws the lower half of the circle on screen
            # (positive Y direction = into the surface)
            pygame.draw.arc(self.screen, color, rect, math.pi, 2 * math.pi, 1)
        except Exception:
            pass

    def _draw_trail(self):
        n = len(self.trail)
        if n < 2:
            return
        for i, pt in enumerate(self.trail):
            t = i / (n - 1)
            r = max(1, int(5 * t))
            color = tuple(int(BG[j] + (TRIG_CLR[j] - BG[j]) * t) for j in range(3))
            pygame.draw.circle(self.screen, color, self.w2s(*pt), r)

    # ── HUD ───────────────────────────────────────────────────────────────────

    def _draw_hud(self, d_a, d_b, raw_pos=None, filtered_pos=None):
        y = 14

        def row(text, color=HUD_CLR):
            nonlocal y
            surf = self.font_m.render(text, True, color)
            self.screen.blit(surf, (14, y))
            y += 20

        if config.MOUSE_MODE:
            mode_label, mode_color = 'MOUSE MODE', (200, 150, 255)
        elif config.SIM_MODE:
            mode_label, mode_color = 'SIM MODE',   (100, 220, 100)
        else:
            mode_label, mode_color = 'SERIAL MODE', (255, 180, 40)
        row(mode_label, mode_color)
        if config.TREMOR_MODE:
            row(f'TREMOR  {config.TREMOR_FREQ_HZ:.0f} Hz  ±{config.TREMOR_AMP_MM:.0f} mm',
                (255, 120, 40))
        y += 6
        row(f'd_A  {d_a:8.1f} mm', LINE_A_CLR)
        row(f'd_B  {d_b:8.1f} mm', LINE_B_CLR)
        y += 6

        if raw_pos:
            rx = raw_pos[0] - config.SURFACE_X0
            ry = raw_pos[1] - config.SURFACE_Y0
            row('--- raw ---', (120, 120, 120))
            row(f'X  {rx:8.1f} mm', (140, 60, 50))
            row(f'Y  {ry:8.1f} mm', (140, 60, 50))

        if filtered_pos and config.FILTER_MODE:
            fx = filtered_pos[0] - config.SURFACE_X0
            fy = filtered_pos[1] - config.SURFACE_Y0
            row('--- filtered ---', (120, 120, 120))
            row(f'X  {fx:8.1f} mm', TRIG_CLR)
            row(f'Y  {fy:8.1f} mm', TRIG_CLR)

        if not raw_pos:
            row('Position: out of range', (255, 80, 80))

    def _draw_legend(self):
        # ── Colour key ────────────────────────────────────────────────────────
        dot_items = [
            (TRUE_CLR,       'True position'),
            (TRIG_CLR,       'Filtered position'),
            ((140, 50, 40),  'Raw triangulated'),
            (LINE_A_CLR,     'Sensor A arc'),
            (LINE_B_CLR,     'Sensor B arc'),
            ((255, 220, 80), 'Manual draw (LMB)'),
            ((80, 220, 255), 'Auto-plot (P)'),
        ]
        x = config.SCREEN_W - 210
        y = 14
        for color, label in dot_items:
            pygame.draw.circle(self.screen, color, (x + 6, y + 7), 5)
            surf = self.font_s.render(label, True, HUD_CLR)
            self.screen.blit(surf, (x + 18, y + 1))
            y += 18

        # ── Key bindings ──────────────────────────────────────────────────────
        y += 6
        def key_row(key, desc, active=None):
            nonlocal y
            if active is True:
                state_color = (100, 220, 100)
                state = ' ON '
            elif active is False:
                state_color = (120, 120, 120)
                state = 'OFF'
            else:
                state_color = HUD_CLR
                state = ''
            key_surf  = self.font_s.render(f'[{key}]', True, (220, 200, 100))
            desc_surf = self.font_s.render(f' {desc}', True, HUD_CLR)
            self.screen.blit(key_surf,  (x, y))
            self.screen.blit(desc_surf, (x + key_surf.get_width(), y))
            if state:
                st_surf = self.font_s.render(f'  {state}', True, state_color)
                self.screen.blit(st_surf,
                                 (x + key_surf.get_width() + desc_surf.get_width(), y))
            y += 17

        key_row('Tab', 'Mouse / Auto',   config.MOUSE_MODE)
        key_row('F',   'Filter',          config.FILTER_MODE)
        key_row('T',   'Tremor',          config.TREMOR_MODE)
        key_row('P',   'Plot path',       self.auto_plot)
        key_row('C',   'Clear canvas')
        key_row('Esc', 'Quit')


# ── Helpers ───────────────────────────────────────────────────────────────────

def MARGIN_PX(scale):
    """Pixel offset so that SURFACE_X0 (negative) maps cleanly into the screen."""
    return int(-config.SURFACE_X0 * scale)
