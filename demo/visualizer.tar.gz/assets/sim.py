import math
import random
import config


def sim_source():
    """
    Yields (d_a, d_b, true_x, true_y).
    Object traces a Lissajous path over the detection surface.
    """
    cx = (config.SURFACE_X0 + config.SURFACE_X1) / 2
    cy = (config.SURFACE_Y0 + config.SURFACE_Y1) / 2
    rx = (config.SURFACE_W_MM / 2) * 0.75
    ry = (config.SURFACE_D_MM / 2) * 0.75

    ax, ay = config.SENSOR_A
    bx, by = config.SENSOR_B

    t = 0.0
    dt = 0.012

    while True:
        true_x = cx + rx * math.sin(3 * t + math.pi / 4)
        true_y = cy + ry * math.sin(2 * t)

        d_a = math.hypot(true_x - ax, true_y - ay)
        d_b = math.hypot(true_x - bx, true_y - by)

        d_a += random.gauss(0, config.SIM_NOISE_MM)
        d_b += random.gauss(0, config.SIM_NOISE_MM)

        t += dt
        yield d_a, d_b, true_x, true_y


def serial_source():
    """
    Yields (d_a, d_b, None, None) parsed from serial port.
    Expected line format:  L:1234,R:5678
    (L = Sensor A / I2C1,  R = Sensor B / I2C2)
    """
    import serial
    ser = serial.Serial(config.SERIAL_PORT, config.BAUD_RATE, timeout=1)
    while True:
        line = ser.readline().decode('ascii', errors='ignore').strip()
        try:
            parts = {}
            for token in line.split(','):
                k, v = token.split(':')
                parts[k.strip()] = float(v.strip())
            yield parts['L'], parts['R'], None, None
        except Exception:
            continue
