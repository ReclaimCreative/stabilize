class SimulinkFilter:
    """
    Discrete Transfer Function ported from PlotterSTM32.c (Simulink model v1.8).

    H(z) = 0.122 * (1 + z^-1) / (1 - 0.7561 * z^-1)

    Direct Form II implementation matching the generated C code:
        v[n] = u[n] + 0.7561 * v[n-1]      (den_accum in C)
        y[n] = 0.122 * v[n] + 0.122 * v[n-1]

    DC gain = 0.122 * 2 / (1 - 0.7561) ≈ 1.0  (unity gain low-pass)
    """

    A1 = -0.7561   # denominator coefficient (sign convention: H = B/A, A[0]=1)
    B0 =  0.122
    B1 =  0.122

    def __init__(self, initial=0.0):
        self.state = initial

    def step(self, u: float) -> float:
        v = u - self.A1 * self.state          # v[n] = u[n] + 0.7561*v[n-1]
        y = self.B0 * v + self.B1 * self.state
        self.state = v
        return y

    def reset(self, value=0.0):
        self.state = value
