import math


def triangulate(d_a: float, d_b: float, baseline: float):
    """
    Law of cosines: Sensor A at origin, Sensor B at (baseline, 0).
    Returns world (x, y) of the object, or None if geometrically invalid.

    Triangle sides:
        c = baseline (A to B)
        d_a = distance from A to object
        d_b = distance from B to object

    Angle at A:  cos(alpha) = (d_a^2 + c^2 - d_b^2) / (2 * d_a * c)
    Object pos:  x = d_a * cos(alpha),  y = d_a * sin(alpha)
    """
    c = baseline
    if d_a <= 0 or d_b <= 0:
        return None
    if d_a + d_b < c or abs(d_a - d_b) > c:
        return None

    cos_alpha = (d_a**2 + c**2 - d_b**2) / (2.0 * d_a * c)
    cos_alpha = max(-1.0, min(1.0, cos_alpha))      # clamp for float safety
    alpha = math.acos(cos_alpha)

    return d_a * math.cos(alpha), d_a * math.sin(alpha)
