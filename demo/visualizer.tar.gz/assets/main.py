import asyncio
import math
import random
import time
import pygame
import config
from sim import sim_source
from filter import SimulinkFilter
from triangulation import triangulate
from viz import Visualizer


async def main():
    viz    = Visualizer()
    source = None          # initialized lazily when first needed

    ax, ay = config.SENSOR_A
    bx, by = config.SENSOR_B

    filt_x = SimulinkFilter()
    filt_y = SimulinkFilter()
    filter_initialized = False

    running = True
    while running:
        running = viz.handle_events()

        if getattr(viz, '_tab_pressed', False):
            source = None
            viz._tab_pressed = False

        if config.MOUSE_MODE:
            true_x, true_y = viz.mouse_world_pos()
        else:
            if source is None:
                source = sim_source()
            d_a, d_b, true_x, true_y = next(source)

        # Apply tremor on top of current position (any mode)
        if config.TREMOR_MODE:
            t = time.time()
            w = 2 * math.pi * config.TREMOR_FREQ_HZ
            true_x += config.TREMOR_AMP_MM * math.sin(w * t)
            true_y += config.TREMOR_AMP_MM * math.sin(w * t + math.pi / 3)

        true_pos = (true_x, true_y)
        d_a = math.hypot(true_x - ax, true_y - ay) + random.gauss(0, config.SIM_NOISE_MM)
        d_b = math.hypot(true_x - bx, true_y - by) + random.gauss(0, config.SIM_NOISE_MM)

        raw = triangulate(d_a, d_b, config.BASELINE_MM)

        filtered_pos = None
        if raw and config.FILTER_MODE:
            if not filter_initialized:
                filt_x.reset(raw[0])
                filt_y.reset(raw[1])
                filter_initialized = True
            filtered_pos = (filt_x.step(raw[0]), filt_y.step(raw[1]))

        viz.render(d_a, d_b, true_pos, raw, filtered_pos)

        await asyncio.sleep(0)  # yield to browser event loop each frame

    pygame.quit()


asyncio.run(main())
