IN_TO_MM = 25.4

# Physical dimensions (mm)
SURFACE_W_MM    = 500.0                    # width along baseline axis
SURFACE_D_MM    = 500.0                    # depth into surface
BASELINE_MM     = 18.0 * IN_TO_MM         # 457.2 mm sensor separation

# World coordinate system:
#   Origin  = Sensor A
#   +X      = along baseline toward Sensor B
#   +Y      = into the surface (depth)
MARGIN_MM = (SURFACE_W_MM - BASELINE_MM) / 2   # sensors inset from surface edges

SENSOR_A = (0.0,          0.0)
SENSOR_B = (BASELINE_MM,  0.0)

# Surface bounding box in world coords
SURFACE_X0 = -MARGIN_MM
SURFACE_X1 = BASELINE_MM + MARGIN_MM
SURFACE_Y0 = 0.0
SURFACE_Y1 = SURFACE_D_MM

# --- Data source ---
# Priority: MOUSE_MODE > SIM_MODE > serial
MOUSE_MODE  = True        # cursor position drives the simulation
SIM_MODE    = True        # False = serial port (only used when MOUSE_MODE is off)
SERIAL_PORT = '/dev/ttyUSB0'
BAUD_RATE   = 460800

SIM_NOISE_MM = 4.0       # Gaussian noise std dev on simulated distances (mm)

# --- Filter ---
FILTER_MODE = True       # apply Simulink IIR filter to triangulated position

# --- Tremor ---
TREMOR_MODE    = False
TREMOR_FREQ_HZ = 5.0     # oscillation frequency (Hz)
TREMOR_AMP_MM  = 20.0    # peak displacement (mm)

# --- Display ---
SCREEN_W  = 1100
SCREEN_H  = 750
FPS       = 60
TRAIL_LEN = 80           # number of past triangulated positions to show
